/******************************************************************************
 * augmented_Qgraph.cpp 
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#include "augmented_Qgraph.h"

augmented_Qgraph::augmented_Qgraph() : m_max_vertex_weight_difference(0) {
                
}

augmented_Qgraph::~augmented_Qgraph() {
                
}

