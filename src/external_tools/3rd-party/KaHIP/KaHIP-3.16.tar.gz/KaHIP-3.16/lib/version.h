#pragma once

#ifdef DETERMINISTIC_PARHIP
const std::string KAHIPVERSION = "v3.14 DETERMINISTIC_PARHIP";
#else 
const std::string KAHIPVERSION = "v3.14";
#endif
