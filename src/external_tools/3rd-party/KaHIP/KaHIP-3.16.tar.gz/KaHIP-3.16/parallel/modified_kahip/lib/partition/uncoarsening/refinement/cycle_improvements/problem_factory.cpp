/******************************************************************************
 * problem_factory.cpp
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#include "problem_factory.h"

problem_factory::problem_factory() {
                
}

problem_factory::~problem_factory() {
                
}

