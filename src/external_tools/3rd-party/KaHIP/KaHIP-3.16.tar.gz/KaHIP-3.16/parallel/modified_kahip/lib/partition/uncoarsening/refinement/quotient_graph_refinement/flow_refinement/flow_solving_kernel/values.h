/******************************************************************************
 * values.h 
 *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 *****************************************************************************/


#define MAXLONG 1073741824
#define atoll (long long) atof
