/******************************************************************************
 * quotient_graph_scheduling.cpp
 * *
 * Source of KaHIP -- Karlsruhe High Quality Partitioning.
 * Christian Schulz <christian.schulz.phone@gmail.com>
 *****************************************************************************/

#include "quotient_graph_scheduling.h"

quotient_graph_scheduling::quotient_graph_scheduling() {
}

quotient_graph_scheduling::~quotient_graph_scheduling() {
                
}

